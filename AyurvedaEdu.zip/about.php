<?php include "header.php"?>
<?php include "otherpageslider.php"?>
<?php include "navigation.php"?>



<?php include "footer.php"?>
<!-- <p>We are prividing service to p.g.ayurveda & other faculty students,since more than 10years. </p>
                <p>We belong to Ayurveda faculty with experience of more than 20 year.</p>
                <p>Since 2011, we have helped more than 100 plus post graduation aspirants to get admission in
                    prefferred subject with lowest possible </p>
                <p>Collage/University fees. Thus helping students to save more money during initial admission itself.
                </p>
                <p>We have tie up with most of private colleges of India.We also understand need od students which is
                    helpfull in choosing University instituation .</p><br> -->