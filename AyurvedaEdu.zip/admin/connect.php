<?php
$conn=mysqli_connect("localhost","root","","ayurveda");
if(!$conn)
{
		echo "not connected";
}
?>