// $(document).ready(function(){
//     $('.multi_select').selectpicker();
// })

// $(document).ready(function () {
//     alert("hi");
//     $("#test").CreateMultiCheckBox({ width: '230px',
//                defaultText : 'Select Below', height:'250px' });
//   });