	<!-- navigation -->
	<div class="navigation-w3ls">
	    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-nav">
	        <button class="navbar-toggler mx-auto" type="button" data-toggle="collapse"
	            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
	            aria-label="Toggle navigation">
	            <span class="navbar-toggler-icon"></span>
	        </button>
	        <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
	            <ul class="navbar-nav justify-content-center">
	                <li class="nav-item active">
	                    <a class="nav-link text-white font-weight-bold " href="index.php">Home
	                        <span class="sr-only">(current)</span>
	                    </a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link text-black font-weight-bold " href="#about33">About Us</a>
	                </li>

	                <li class="nav-item">
	                    <a class="nav-link text-black font-weight-bold" href="#services1">Services</a>
	                </li>

	                <li class="nav-item dropdown">
	                    <a class="nav-link text-black font-weight-bold " href="#register1">
	                        Registration
	                    </a>
	                </li>

	                <li class="nav-item">
	                    <a class="nav-link text-black font-weight-bold " href="#gallery1">Gallery</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link text-black font-weight-bold" href="#contact1">Contact Us</a>
	                </li>
	            </ul>
	        </div>
	    </nav>
	</div>
	<!-- //navigation -->
	</div>
	<!-- //banner -->